import cv2 as cv
import cv.aruco as aruco


aruco.CharucoBoard board = 