import cv2
from cv2 import aruco

aruco_dict = aruco.Dictionary_get(aruco.DICT_5X5_250)
aruco_dict.bytesList=aruco_dict.bytesList[:,:,:]
board = aruco.CharucoBoard_create(14, 8, 200, 100, aruco_dict) #Square X, Square Y, Square length, marker length, 

imboard = board.draw((2000, 2000))
cv2.imwrite("chessboarVeryVeryBig.png", imboard)