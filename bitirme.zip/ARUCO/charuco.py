"""
import cv2
from cv2 import aruco

aruco_dict = aruco.Dictionary_get(aruco.DICT_5X5_250)
aruco_dict.bytesList=aruco_dict.bytesList[:,:,:]
board = aruco.CharucoBoard_create(14, 8, 200, 100, aruco_dict) #Square X, Square Y, Square length, marker length, 

imboard = board.draw((2000, 2000))
cv2.imwrite("chessboarVeryVeryBig.png", imboard)
"""

import time
import cv2
from cv2 import aruco
import cv2.aruco
import numpy as np
import pickle

dictionary = cv2.aruco.Dictionary_get(cv2.aruco.DICT_5X5_250)
board = cv2.aruco.CharucoBoard_create(14, 8, 200, 100, dictionary)

image_board = board.draw((200*3, 200*3))

cv2.imwrite('charuco.png', image_board)

cap = cv2.VideoCapture(0)

all_corners = []
all_ids = []
counter = 0
for i in range(300):
    ret,frame = cap.read()
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    res = cv2.aruco.detectMarkers(gray, dictionary)
    frame_custom = frame
    if len(res[0]) > 0:
        res2 = cv2.aruco.interpolateCornersCharuco(res[0], res[1], gray, board)
        if res2[1] is not None and res2[2] is not None and len(res2[1]) > 3 and counter % 3 == 0:
            all_corners.append(res2[1])
            all_ids.append(res2[2])

        cv2.aruco.drawDetectedMarkers(gray, res[0], res[1])

    cv2.imshow('frame', gray)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    counter += 1


try:
    call = cv2.aruco.calibrateCameraCharuco(all_corners, all_ids, board, gray.shape, None, None)
except:
    cap.release()
    print("Calibration could not be done......")

retval, cameraMatrix, distCoeffs, rvecs, tvecs = call

print(cameraMatrix)
print(distCoeffs)

#f = open('calibration2.pckl', 'wb')
#pickle.dump((cameraMatrix,distCoeffs) , f)
#with open("parameters.txt", "wb") as file_handler:
#    pickle.dump((cameraMatrix,distCoeffs) , (file_handler))

f = open("calib.txt", 'wb')
f.write(cameraMatrix)


h,  w = frame_custom.shape[:2]
newcameramtx, roi = cv2.getOptimalNewCameraMatrix(cameraMatrix, distCoeffs, (w,h), 1, (w,h))

dst = cv2.undistort(frame, cameraMatrix, distCoeffs, None ,newcameramtx)
# crop the image
x, y, w, h = roi
dst = dst[y:y+h, x:x+w]
cv2.imwrite('calibresult.png', dst)


f.close()

cap.release()
cv2.destroyAllWindows()


